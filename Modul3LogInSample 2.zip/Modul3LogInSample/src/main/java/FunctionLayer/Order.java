/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FunctionLayer;

/**
 *
 * @author mohammahomarhariri
 */
public class Order {

    private int user_id;
    private int height;
    private int width;
    private int length;
    private int orderid;
    private boolean sent;

    public Order(int height, int width, int length, boolean sent) {
        this.height = height;
        this.width = width;
        this.length = length;
        this.sent = sent;

    }

    public Order(int orderid, int id, int height, int length, int width, boolean sent) {
        this.height = height;
        this.width = width;
        this.length = length;
        this.sent = sent;
        this.orderid = orderid;
        this.user_id = id;
    }

    public Order(int orderid, int id, int h, int l, int w, int sent) {

        this.height = h;
        this.width = w;
        this.length = l;
        this.orderid = orderid;
        this.user_id = id;
        if (sent == 0) {
            this.sent = false;
        } else {
            this.sent = true;
        }
    }

    public Order(int user_id, int length, int width, int height, boolean b) {
        this.height = height;
        this.width = width;
        this.length = length;
        this.sent = sent;
        this.user_id = user_id;
    }

    public int getId() {
        return user_id;
    }

    public void setId(int id) {
        this.user_id = id;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public boolean isSent() {
        return sent;
    }

    public void setSent(boolean sent) {
        this.sent = sent;
    }

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    @Override
    public String toString() {
        return "[ Order:" + "id=" + " " + user_id + " "+ "orderid:= " +orderid  + " "+ "height=" + height + " "+ "width=" + width + " "+  "length=" + length + " "+ "Shipped =" + sent + "      ]";
    }

}
