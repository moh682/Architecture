package FunctionLayer;

import DBAccess.OrderMapper;
import DBAccess.UserMapper;
import java.util.List;

/**
 * The purpose of LogicFacade is to...
 *
 * @author kasper
 */
public class LogicFacade {

    public static User login(String email, String password) throws LoginSampleException {
        return UserMapper.login(email, password);
    }

    public static User createUser(String email, String password) throws LoginSampleException {
        User user = new User(email, password, "customer");
        UserMapper.createUser(user);
        return user;
    }

    public static void createOrder(int height, int width, int length, boolean sent) throws LoginSampleException,OrderException {
        Order order = new Order(height, width, length, sent);
        OrderMapper.createOrder(order);
    }

    public static Order getOrder(int id) throws LoginSampleException,OrderException {
        return OrderMapper.getOrder(id);
    }

    public static List<Order> getOrderList(User user) throws LoginSampleException,OrderException{
            return OrderMapper.getOrderList(user);
    }

    public static List<Order> getAllOrders() throws LoginSampleException,OrderException {
        return OrderMapper.getAllOrders();

    }

    public static void createOrder(int user_id, int height, int width, int length, boolean b) throws OrderException{
        Order order = new Order(user_id, length, width, height, b);
        OrderMapper.createOrder(order);
    }
    
    public static void changeOrder(int orderid) throws OrderException{
        OrderMapper.changeOrder(orderid);
        
    }
    
}
