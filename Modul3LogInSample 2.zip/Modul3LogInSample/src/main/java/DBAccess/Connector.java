package DBAccess;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 The purpose of Connector is to...

 @author kasper
 */
public class Connector {

    //private static final String URL = "jdbc:mysql://46.101.253.149:3306/useradmin";
    private static final String URL = "jdbc:mysql://159.65.117.47:3306/Architecture";
    private static final String USERNAME = "mohammad";
    private static final String PASSWORD = "haririboy";

    private static Connection singleton;

    public static void setConnection( Connection con ) {
        singleton = con;
    }

    public static Connection connection() throws ClassNotFoundException, SQLException {
        if ( singleton == null ) {
            Class.forName( "com.mysql.cj.jdbc.Driver" );
            singleton = DriverManager.getConnection( URL, USERNAME, PASSWORD );
        }
        return singleton;
    }

}
