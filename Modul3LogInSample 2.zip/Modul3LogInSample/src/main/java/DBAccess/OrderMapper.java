/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DBAccess;

import FunctionLayer.LoginSampleException;
import FunctionLayer.Order;
import FunctionLayer.OrderException;
import FunctionLayer.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author mohammahomarhariri
 */
public class OrderMapper {

    public static boolean createOrder(Order order) throws OrderException {
        try {
            Connection con = Connector.connection();
            String SQL = "INSERT INTO orders (id, length, width, height, sent) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement rs = con.prepareStatement(SQL);
            rs.setInt(1, order.getId());
            rs.setInt(2, order.getLength());
            rs.setInt(3, order.getWidth());
            rs.setInt(4, order.getHeight());
            rs.setBoolean(5, order.isSent());
            rs.executeUpdate();
        } catch (SQLException | ClassNotFoundException ex) {
            throw new OrderException(ex.getMessage());
        }

        return false;
    }

    public static Order getOrder(int id) throws OrderException {
        try {
            Connection con = Connector.connection();
            String SQL = "SELECT * FROM orders WHERE id=? ";
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int l = rs.getInt("length");
                int w = rs.getInt("width");
                int h = rs.getInt("height");
                boolean sent = rs.getBoolean("sent");

                Order order = new Order(h, w, l, sent);
                return order;
            } else {
                throw new OrderException("Could not validate Order");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw new OrderException(ex.getMessage());
        }
    }

    /**
     *
     * @param user session user
     * @return orders linked to user_id
     * @throws LoginSampleException
     */
    public static List<Order> getOrderList(User user) throws OrderException, LoginSampleException {

        List<Order> list;

        try {

            Connection con = Connector.connection();
            String SQL = "SELECT * FROM orders WHERE id=? ";

            PreparedStatement ps = con.prepareStatement(SQL);

            ps.setInt(1, user.getId());
            ResultSet rs = ps.executeQuery();

            list = new ArrayList<>();

            while (rs.next()) {
                int length = rs.getInt("length");
                int width = rs.getInt("width");
                int height = rs.getInt("height");
                int id = rs.getInt("id");
                int orderid = rs.getInt("orderid");
                int sent = rs.getInt("sent");

                list.add(new Order(orderid, id, height, length, width, sent));

            }
            return list;
        } catch (ClassNotFoundException | SQLException ex) {
            throw new OrderException(ex.getMessage());
        }

    }

    public static List<Order> getAllOrders() throws OrderException {
        try {

            List<Order> list = new ArrayList<>();

            Connection con = Connector.connection();
            String SQL = "SELECT * FROM orders ";
            PreparedStatement ps = con.prepareStatement(SQL);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {

                int length = rs.getInt("length");
                int width = rs.getInt("width");
                int height = rs.getInt("height");
                int id = rs.getInt("id");
                int orderid = rs.getInt("orderid");
                boolean sent = rs.getBoolean("sent");

                list.add(new Order(orderid, id, height, length, width, sent));

            }
            return list;
        } catch (ClassNotFoundException | SQLException ex) {
            throw new OrderException(ex.getMessage());
        }
    }

    public static void changeOrder(int orderid) throws OrderException {
        try {

            Connection con = Connector.connection();
            String SQL = "SELECT * FROM orders WHERE orderid=?";
            PreparedStatement ps = con.prepareStatement(SQL);
            ps.setInt(1, orderid);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {

                String nextSQL = "UPDATE orders SET sent='1'";
                ps.execute(nextSQL);

            } else {
                System.out.println("doesnt exist in database");
            }
        } catch (ClassNotFoundException | SQLException ex) {
            throw new OrderException(ex.getMessage());
        }
    }

}
