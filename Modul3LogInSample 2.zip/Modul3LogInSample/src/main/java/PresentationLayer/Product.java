package PresentationLayer;

import FunctionLayer.LogicFacade;
import FunctionLayer.LoginSampleException;
import FunctionLayer.Order;
import FunctionLayer.OrderException;
import FunctionLayer.User;
import static java.lang.Math.abs;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Product extends Command {

    @Override
    String execute(HttpServletRequest request, HttpServletResponse response) throws LoginSampleException,OrderException {
        
        User user = (User) request.getSession().getAttribute("user");
        int user_id = user.getId();
        
        int length = Integer.parseInt(request.getParameter("length"));
        int width = Integer.parseInt(request.getParameter("width"));
        int height = Integer.parseInt(request.getParameter("height"));
         
        LogicFacade.createOrder(user_id ,height, width, length, false);
        
        request.setAttribute("length", length);
        request.setAttribute("width", width);
        request.setAttribute("height", height);
        
        int totalDots = ((length * 2) + (width * 2)) * height * 2;

        int lengthSmallBrick = abs((length % 2));
        int lengthMediumBrick = abs((length % 4) / 2);
        int lengthLargeBrick = abs((length / 4));

        width = width - 4;
        int widthSmallBrick = abs((width % 2));
        int widthMediumBrick = abs((width % 4) / 2);
        int widthLargeBrick = abs(width / 4);

        int smallTotalLength = abs(lengthSmallBrick);
        int mediumTotalLength = abs(lengthMediumBrick);
        int largeTotalLength = abs(lengthLargeBrick);

        int smallTotalWidth = widthSmallBrick;
        int mediumTotalWidth = widthMediumBrick;
        int largeTotalWidth = widthLargeBrick;

        int totalSmallBricks = abs((((smallTotalLength * 2) + (smallTotalWidth * 2)) * height));
        int totalMediumBricks = abs((((mediumTotalLength * 2) + (mediumTotalWidth * 2)) * height));
        int totalLargeBricks = abs((((largeTotalLength * 2) + (largeTotalWidth * 2)) * height));

        List<Integer> bList = new ArrayList<>();
        bList.add(lengthSmallBrick);
        bList.add(lengthMediumBrick);
        bList.add(lengthLargeBrick);
        bList.add(widthSmallBrick);
        bList.add(widthMediumBrick);
        bList.add(widthLargeBrick);

        int brickCounter = 0;

        for (int b : bList) {
            brickCounter += b * height * 2;
        }

        request.setAttribute("largeBricks", lengthLargeBrick);
        request.setAttribute("largeBricksWidth", widthLargeBrick);
        request.setAttribute("allBricksLarge", totalLargeBricks);
        
        request.setAttribute("mediumBricks", lengthMediumBrick);
        request.setAttribute("mediumBricksWidth", widthMediumBrick);
        request.setAttribute("allBricksMedium", totalMediumBricks);
        
        request.setAttribute("smallBricks", lengthSmallBrick);
        request.setAttribute("smallBricksWidth", widthSmallBrick);
        request.setAttribute("allSmallBricks", totalSmallBricks);
        
        
        
        return "product";
    }

}
