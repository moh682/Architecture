/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PresentationLayer;

/**
 *
 * @author mohammahomarhariri
 */
public class Wall {
//
//    private int length;
//    private int width;
//    private int height;
//
//    private int totalRow1;
//    private int totalRow2;
//
//    private int l = length;
//    private int w = width;
//    private int h = height;
//
//    //row 1
//    private int fourXtwoLength1 = l / 4;
//    private int twoXtwoLength1 = (l % 4) / 2;
//    private int oneXtwoLength1 = ((l % 4) % 2) / 1;
//    private int fourXtwoWidth1 = ((w - 4) / 4);
//    private int twoXtwoWidth1 = (((w - 4) % 4) / 2);
//    private int oneXtwoWidth1 = (((w - 4) % 4) % 2) / 1;
//
//    //row 2
//    private int twoXtwoLength2 = l / 2;
//    private int oneXtwoLength2 = (l % 2) / 1;
//    private int twoXtwoWidth2 = ((w - 4) / 2);
//    private int oneXtwoWidth2 = ((w - 4) % 2) / 1;
//
//    private int largeRes1 = (fourXtwoLength1 * 2) + (fourXtwoWidth1 * 2);
//    private int mediumRes1 = (twoXtwoLength1 * 2) + (twoXtwoWidth1 * 2);
//    private int smallRes1 = (oneXtwoLength1 * 2) + (oneXtwoWidth1 * 2);
//    
//    private int mediumRes2 = (twoXtwoLength2 * 2) + (twoXtwoWidth2 * 2);
//    private int smallRes2 = (oneXtwoLength2 * 2) + (oneXtwoWidth2 * 2);
//    
//
//    public Wall(int length, int width, int height) {
//        this.length = length;
//        this.width = width;
//        this.height = height;
//    }
//
//    /**
//     * formats the walls stones to blockforbandt style
//     */
//
//    public int calculateRow2() {
//
//        //for length
//        int l = length - 1;
//
//        countSmallBricksL++;
//
//        int mediumBricksLength = (l % 2) / 2;
//        int smallBricksLength = ((l % 2) % 2) / 1;
//
//        countMediumBricksL = mediumBricksLength * 2;
//        countMediumBricksL = smallBricksLength * 2;
//
//        //for width
//        int w = width - 4;
//
//        int mediumBricksWidth = ((w - 4) % 2) / 2;
//        int smallBricksWidth = (((w - 4) % 2) % 2) / 1;
//
//        //for Width
//        countMediumBricksW = mediumBricksWidth * 2;
//        countSmallBricksW = smallBricksWidth * 2;
//
//    }
//
//    public void calculateTotal() {
//        int countrow1 = 0;
//        int countrow2 = 0;
//
//        for (int i = 0; i < height; i++) {
//            boolean first = true;
//            if (first == true) {
//                countrow1++;
//                first = false;
//            } else {
//                countrow2++;
//                first = true;
//            }
//        }
//
//        int l = countLargeBricksL + countLargeBricksW;
//        System.out.println("Large Bricks: " + l);
//
//        int m = countMediumBricksL + countMediumBricksW;
//        System.out.println("Medium Bricks: " + m);
//
//        int s = countSmallBricksL + countSmallBricksW;
//        System.out.println("Small Bricks: " + s);
//
//    }
//
//    public int getPrice() {
//        return price;
//    }
//
//    public void setPrice(int price) {
//        this.price = price;
//    }
//
//    public int getLength() {
//        return length;
//    }
//
//    public void setLength(int length) {
//        this.length = length;
//    }
//
//    public int getWidth() {
//        return width;
//    }
//
//    public void setWidth(int width) {
//        this.width = width;
//    }
//
//    public int getHeight() {
//        return height;
//    }
//
//    public void setHeight(int height) {
//        this.height = height;
//    }
//
//    public int getTotalRow1() {
//        return totalRow1;
//    }
//
//    public void setTotalRow1(int totalRow1) {
//        this.totalRow1 = totalRow1;
//    }
//
//    public int getTotalRow2() {
//        return totalRow2;
//    }
//
//    public void setTotalRow2(int totalRow2) {
//        this.totalRow2 = totalRow2;
//    }
//
//    public int getCountLargeBricksL() {
//        return countLargeBricksL;
//    }
//
//    public void setCountLargeBricksL(int countLargeBricksL) {
//        this.countLargeBricksL = countLargeBricksL;
//    }
//
//    public int getCountMediumBricksL() {
//        return countMediumBricksL;
//    }
//
//    public void setCountMediumBricksL(int countMediumBricksL) {
//        this.countMediumBricksL = countMediumBricksL;
//    }
//
//    public int getCountSmallBricksL() {
//        return countSmallBricksL;
//    }
//
//    public void setCountSmallBricksL(int countSmallBricksL) {
//        this.countSmallBricksL = countSmallBricksL;
//    }
//
//    public int getCountLargeBricksW() {
//        return countLargeBricksW;
//    }
//
//    public void setCountLargeBricksW(int countLargeBricksW) {
//        this.countLargeBricksW = countLargeBricksW;
//    }
//
//    public int getCountMediumBricksW() {
//        return countMediumBricksW;
//    }
//
//    public void setCountMediumBricksW(int countMediumBricksW) {
//        this.countMediumBricksW = countMediumBricksW;
//    }
//
//    public int getCountSmallBricksW() {
//        return countSmallBricksW;
//    }
//
//    public void setCountSmallBricksW(int countSmallBricksW) {
//        this.countSmallBricksW = countSmallBricksW;
//    }
//
}
